OC.L10N.register(
    "epubreader",
    {
    "menu" : "мени"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
