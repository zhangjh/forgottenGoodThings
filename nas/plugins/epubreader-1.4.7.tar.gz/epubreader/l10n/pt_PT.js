OC.L10N.register(
    "epubreader",
    {
    "disable extra-wide page turn areas" : "desativar areas de viragem de página extra-largas",
    "show page turn arrows" : "mostrar botões de virar a página",
    "menu" : "menu",
    "Reader" : "Leitor",
    "Select file types for which Reader should be the default viewer." : "Escolha os tipos de ficheiros para os quais o Leitor deva ser associado por predefinição.",
    "Epub" : "Epub",
    "PDF" : "PDF",
    "CBR/CBZ" : "CBR/CBZ"
},
"nplurals=2; plural=(n != 1);");
