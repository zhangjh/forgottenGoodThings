OC.L10N.register(
    "epubreader",
    {
    "menu" : "Meny"
},
"nplurals=2; plural=(n != 1);");
