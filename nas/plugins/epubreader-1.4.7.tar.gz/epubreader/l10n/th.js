OC.L10N.register(
    "epubreader",
    {
    "Settings updated successfully." : "อัปเดทการตั้งค่าสำเร็จ",
    "EPUB/CBZ/PDF ebook reader" : "ตัวอ่านอีบุ๊ค EPUB/CBZ/PDF",
    "custom font" : "ตัวอักษรกำหนดเอง",
    "font size" : "ขนาดตัวอักษร",
    "font weight" : "น้ำหนักตัวอักษร",
    "Use custom colors" : "ใช้สีกำหนดเอง",
    "show page turn arrows" : "แสดงลูกศรเปลี่ยนหน้า",
    "menu" : "เมนู",
    "Reader" : "ผู้อ่าน",
    "Epub" : "Epub",
    "PDF" : "PDF",
    "CBR/CBZ" : "CBR/CBZ"
},
"nplurals=1; plural=0;");
