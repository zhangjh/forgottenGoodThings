OC.L10N.register(
    "epubreader",
    {
    "Settings updated successfully." : "Asetukset päivitettiin onnistuneesti.",
    "EPUB/CBZ/PDF ebook reader" : "EPUB/CBZ/PDF-kirjanlukija",
    "custom font" : "mukautettu fontti",
    "monospace" : "tasalevyinen",
    "font size" : "fontin koko",
    "font weight" : "fontin paino",
    "Use custom colors" : "Käytä mukautettuja värejä",
    "night mode can be toggled by clicking the book title" : "yötilan voi ottaa käyttöön tai poistaa käytöstä napsauttamalla kirjan otsikkoa",
    "reflow text when sidebars are open" : "rivitä teksti uudelleen kun sivupalkit ovat avoinna",
    "show page turn arrows" : "näytä nuolet sivun kääntämiseksi",
    "menu" : "Valikko",
    "Reader" : "Lukija",
    "Select file types for which Reader should be the default viewer." : "Valitse tiedostotyypit, joihin Lukija asetetaan oletuskatselimeksi.",
    "Epub" : "Epub",
    "PDF" : "PDF",
    "CBR/CBZ" : "CBR/CBZ"
},
"nplurals=2; plural=(n != 1);");
