OC.L10N.register(
    "epubreader",
    {
    "menu" : "kieslys",
    "Reader" : "Leser",
    "Epub" : "Epub",
    "PDF" : "PDF",
    "CBR/CBZ" : "CBR/CBZ"
},
"nplurals=2; plural=(n != 1);");
