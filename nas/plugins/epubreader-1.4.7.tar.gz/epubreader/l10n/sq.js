OC.L10N.register(
    "epubreader",
    {
    "menu" : "Menu"
},
"nplurals=2; plural=(n != 1);");
