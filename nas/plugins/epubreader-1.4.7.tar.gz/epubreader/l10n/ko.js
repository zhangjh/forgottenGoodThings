OC.L10N.register(
    "epubreader",
    {
    "menu" : "메뉴"
},
"nplurals=1; plural=0;");
