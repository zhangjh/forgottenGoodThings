OC.L10N.register(
    "epubreader",
    {
    "Settings updated successfully." : "Paramètres corrèctament actualizats.",
    "EPUB/CBZ/PDF ebook reader" : "lector d’ebook EPUB/CBZ/PDF",
    "font size" : "talha poliça",
    "font weight" : "largor poliça",
    "menu" : "menú",
    "Reader" : "Lector",
    "Epub" : "Epub",
    "PDF" : "PDF",
    "CBR/CBZ" : "CBR/CBZ"
},
"nplurals=2; plural=(n > 1);");
