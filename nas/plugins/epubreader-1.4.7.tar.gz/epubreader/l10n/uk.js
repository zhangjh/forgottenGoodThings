OC.L10N.register(
    "epubreader",
    {
    "Settings updated successfully." : "Налаштування успішно оновлено.",
    "EPUB/CBZ/PDF ebook reader" : "Електронна читалка для EPUB/CBZ/PDF",
    "custom font" : "користувацький шрифт",
    "monospace" : "моноширинний",
    "font size" : "розмір шрифту",
    "font weight" : "товщина шрифту",
    "Use custom colors" : "Використовувати власні кольори",
    "night mode can be toggled by clicking the book title" : "нічний режим можна увімкнути, якщо натиснути на назву книги",
    "reflow text when sidebars are open" : "прогортати текст, коли відкрито бокові панелі",
    "disable extra-wide page turn areas" : "не показувати область перегортання сторінок з великою шириною",
    "show page turn arrows" : "показувати стрілки для гортання сторінок",
    "menu" : "меню",
    "Reader" : "Читалка",
    "Select file types for which Reader should be the default viewer." : "Виберіть типи файлів, для яких Читалку буде встановлено типовим переглядачем."
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
