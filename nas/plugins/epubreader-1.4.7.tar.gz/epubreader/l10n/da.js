OC.L10N.register(
    "epubreader",
    {
    "Settings updated successfully." : "Indstillingerne er opdateret.",
    "EPUB/CBZ/PDF ebook reader" : "EPUB/CBZ/PDF ebogslæser",
    "custom font" : "Brugerdefineret skrifttype",
    "font size" : "Skriftstørrelse",
    "Use custom colors" : "Brug brugerdefinerede farver",
    "menu" : "menu",
    "Epub" : "Epub",
    "PDF" : "PDF",
    "CBR/CBZ" : "CBR/CBZ"
},
"nplurals=2; plural=(n != 1);");
